"use client";

import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Panel } from 'primereact/panel';

import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
//import { provincias, cantonesPorProvincia, sitiosPorCanton, postCalculos } from '@/hooks/servicios';
import { provincias, cantonesPorProvincia, sitiosPorCanton, postCalculos } from '../../../hooks/servicios';
//import { Link } from 'components';
import { Link } from 'next/link';
//import { LayoutContext } from '../../../../layout/context/layoutcontext'; 
//import { userService, alertService } from 'services';
import { useState } from 'react';
export default function Home() {
    const [listaprovincia, setListaprovincia] = useState([]);
    const [estadoP, setEstadoP] = useState(false);
    const [listaCanton, setListaCanton] = useState([]);
    const [listaSitios, setListaSitios] = useState([]);

    //tabla

    const [calculos, setCalculos] = useState([]);
    const [eneria, setEnergia] = useState(0.0);
    const [superficie, setSuperficie] = useState(0.0);

    const changeSelectOptionHandlerP = (event) => {

        if (event.target.value) {
            cantonesPorProvincia(event.target.value).then((info) => {
                //console.log(info);
                if (info.props.data.message === 'OK') {
                    setListaCanton(info.props.data.datos);

                }
            });
        }
    };
    const changeSelectOptionHandlerC = (event) => {

        if (event.target.value) {
            sitiosPorCanton(event.target.value).then((info) => {
                console.log(info);
                if (info.props.data.message === 'OK') {
                    setListaSitios(info.props.data.datos);

                }
            });
        }
    };
    if (!estadoP) {
        provincias().then((info) => {

            if (info.props.data.message === 'OK') {
                setListaprovincia(info.props.data.datos);

                setEstadoP(true);
            }

        });
    }

    //<coef_reflexion>/<inclinacion>/<orientacion>/<external>/<potencia>/<eficiencia>/<fs>/<rendimiento>
    const validationSchema = Yup.object().shape({
        coef_reflexion: Yup.number()
            .required('Se requiere el coeficiente de reflexion'),
        inclinacion: Yup.number()
            .required('se requiere la inclinacion'),
        orientacion: Yup.number()
            .required('se requiere la orientacion'),
        external: Yup.string()
            .required('Se requiere el sitio'),
        potencia: Yup.number()
            .required('se requiere la potencia'),
        eficiencia: Yup.number()
            .required('se requiere la eficiencia'),
        fs: Yup.number()
            .required('se requiere el factor de sombras'),
        rendimiento: Yup.number()
            .required('se requiere el rendimiento')
    });

    const onSubmit = (data) => {
        var datos = {
            "coef_reflexion": data.coef_reflexion,
            "inclinacion": data.inclinacion,
            "orientacion": data.orientacion,
            "potencia": data.potencia,
            "external": data.external,
            "eficiencia": data.eficiencia,
            "fs": data.fs,
            "rendimiento": data.rendimiento
        };
        console.log(data);
        postCalculos(data).then((info) => {
            console.log(info);
            if (info.props.datos.message === 'OK') {
                console.log("calculos");
                var aux = info.props.datos.datos[0].calculos;
                var aux1 = [];
                console.log(aux);
                
                aux.map(function (key, i) {
                    aux1[i] = { "mes": key[0].mes, "dia": key[1].dia, "eps": key[2].eps, "declinacion": key[3].declinacion, "none": key[4].none, "w0": key[5].w0, "w180": key[6].w180, "wsard": key[7].wsard, "ws0": key[8].ws0, "bodm": key[9].bodm, "gdm": key[10].gdm, "ktm": key[11].ktm, "kdm": key[12].kdm, "ddm": key[13].ddm, "bdm0": key[14].bdm0, "bdmab": key[16].bdmab, "ddmab": key[17].ddmab, "rdmab": key[18].rdmab, "idp": key[19].idpmgdm };
                   
                });
                setCalculos(aux1);
                console.log(aux1);
                console.log(info.props.datos.datos[4].energia_util_estimada);
                setEnergia(info.props.datos.datos[4].energia_util_estimada);
                setSuperficie(info.props.datos.datos[5].superficie);
            } else {
                setCalculos([]);
                //setTitles([]);
            }

        });
        //console.log(datos);
    }

    const formOptions = { resolver: yupResolver(validationSchema) };

    // set default form values if in edit mode
    //if (!isAddMode) {
    //  formOptions.defaultValues = props.user;
    //}

    // get functions to build form with useForm() hook
    const { register, handleSubmit, reset, formState } = useForm(formOptions);
    const { errors } = formState;

    //const { register, handleSubmit, formState: { errors } } = useForm();
    //onSubmit={handleSubmit(onSubmit)}
    return (
        <main className="col-12">



            <div className="card p-fluid">
                <form onSubmit={handleSubmit(onSubmit)} >

                    <div className="form-row">
                        <div className="field p-fluid">
                            <label>Provincia</label>

                            <select name="provincia" {...register('provincia')} className={`p-dropdown p-component p-inputwrapper ${errors.provincia ? 'p-invalid' : ''}`} onChange={changeSelectOptionHandlerP}>
                                <option>Seleccione una provincia</option>
                                {listaprovincia.map((prov, i) => (
                                    <option key={i} value={prov.external}>{prov.nombre}</option>

                                ))}
                            </select>
                            <div className="p-error">{errors.firstName?.message}</div>
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="field p-fluid">
                            <label>Seleccione el canton</label>
                            <select name="canton" {...register('canton')} className={`p-dropdown p-component p-inputwrapper ${errors.canton ? 'p-invalid' : ''}`} onChange={changeSelectOptionHandlerC}>
                                <option>Seleccione un canton</option>
                                {listaCanton.map((cant, i) => (
                                    <option key={i} value={cant.external}>{cant.nombre}</option>

                                ))}
                            </select>
                            <div className="p-error">{errors.canton?.message}</div>
                        </div>
                        <div className="form-row">
                            <div className="field p-fluid">
                                <label>Seleccione el Lugar</label>
                                <select name="external" {...register('external', {
                                    required: true
                                })} className={`p-dropdown p-component p-inputwrapper ${errors.external ? 'p-invalid' : ''}`} >
                                    <option value="">Seleccione un lugar</option>
                                    {listaSitios.map((sit, i) => (
                                        <option key={i} value={sit.external}>{sit.nombre}</option>

                                    ))}
                                </select>
                                <div className="p-error">{errors.external?.message}</div>
                            </div>
                        </div>
                        <div className="form-row">
                            <div className="field p-fluid">
                                <label>Coeficiente de reflexion</label>
                                <InputText name="coef_reflexion" type="text" {...register('coef_reflexion')} className={`${errors.coef_reflexion ? 'p-invalid' : ''}`} />

                                <div className="p-error">{errors.coef_reflexion?.message}</div>
                            </div>
                        </div>
                        <div className="form-row">
                            <div className="field p-fluid">
                                <label>Angulo de inclinacion</label>
                                <InputText name="inclinacion" type="text" {...register('inclinacion')} className={`form-control ${errors.inclinacion ? 'p-invalid' : ''}`} />
                                <div className="p-error">{errors.inclinacion?.message}</div>
                            </div>
                        </div>
                        <div className="form-row">
                            <div className="field p-fluid">
                                <label>Orientacion</label>
                                <InputText name="orientacion" type="text" {...register('orientacion')} className={`form-control ${errors.orientacion ? 'p-invalid' : ''}`} />
                                <div className="p-error">{errors.orientacion?.message}</div>
                            </div>
                        </div>
                        <div className="form-row">
                            <div className="field p-fluid">
                                <label>Potencia</label>
                                <InputText name="potencia" type="text" {...register('potencia')} className={`form-control ${errors.potencia ? 'p-invalid' : ''}`} />
                                <div className="p-error">{errors.potencia?.message}</div>
                            </div>
                        </div>

                        <div className="form-row">
                            <div className="field p-fluid">
                                <label>Eficiencia</label>
                                <InputText name="eficiencia" type="text" {...register('eficiencia')} className={`form-control ${errors.eficiencia ? 'p-invalid' : ''}`} />
                                <div className="p-error">{errors.eficiencia?.message}</div>
                            </div>
                        </div>
                        <div className="form-row">
                            <div className="field p-fluid">
                                <label>Factor de sombra</label>
                                <InputText name="fs" type="text" {...register('fs')} className={`form-control ${errors.fs ? 'p-invalid' : ''}`} />
                                <div className="p-error">{errors.fs?.message}</div>
                            </div>
                        </div>
                        <div className="form-row">
                            <div className="field p-fluid">
                                <label>Rendimiento</label>
                                <InputText name="rendimiento" type="text" {...register('rendimiento')} className={`form-control ${errors.rendimiento ? 'p-invalid' : ''}`} />
                                <div className="p-error">{errors.rendimiento?.message}</div>
                            </div>
                        </div>



                    </div>
                    <div className="formgrid grid">
                        <div className="field col">
                            <Button severity="success" type="submit" disabled={formState.isSubmitting} className="mr-2">
                                {formState.isSubmitting && <span className="spinner-border spinner-border-sm mr-1"></span>}
                                Calcular
                            </Button>
                        </div>
                        <div className="field col">
                            <Button onClick={() => reset(formOptions.defaultValues)} type="button" disabled={formState.isSubmitting} className="btn btn-secondary">Nuevo calculo</Button>

                        </div>


                    </div>
                </form>
            </div>


            <div style={{ display: calculos.length > 0 ? "block" : "none" }} className="card p-fluid">
                <div className='card'>
                    <Panel header="Energía útil estimada">
                        <p className="m-0">
                            {eneria} kWh/año
                        </p>
                    </Panel>
                    <Panel header="Superficie requerida">
                        <p className="m-0">
                            {superficie} m2
                        </p>
                    </Panel>
                </div>
                <div className='card'>
                    <DataTable value={calculos} tableStyle={{ minWidth: '50rem' }}>
                        <Column field="mes" header="Mes"></Column>
                        <Column field="dia" header="Dia"></Column>
                        <Column field="eps" header="Eps.o"></Column>
                        <Column field="declinacion" header="Declinacion"></Column>
                        <Column field="none" header=" "></Column>
                        <Column field="w0" header="Elevacion w=0"></Column>
                        <Column field="w180" header="Elevacion w=180"></Column>
                        <Column field="wsard" header="Ws"></Column>
                        <Column field="ws0" header="Ws o"></Column>
                        <Column field="bodm" header="Gdm(0)"></Column>
                        <Column field="ktm" header="Ktm"></Column>
                        <Column field="kdm" header="Kdm"></Column>
                        <Column field="ddm" header="Ddm(0)"></Column>
                        <Column field="bdm" header="Bdm(0)"></Column>
                        <Column field="idp" header="Irradiación diaria promedio mensual Gdm(a,b)"></Column>

                    </DataTable>
                </div>


            </div>

        </main>
    )
}